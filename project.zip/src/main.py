from Student import Student
from Class import Class
from configuration import *
from visual import Visual
import time

myClass = Class(NUM_STUDENTS, NUM_DAYS)

# run the simulation
v = Visual(myClass.students)
v.showClass()
for i in range(NUM_DAYS):
    myClass.useDay(report=True)
    time.sleep(DAY_DELAY)
    v.updateClass(myClass.students, i)
v.dontClose()
