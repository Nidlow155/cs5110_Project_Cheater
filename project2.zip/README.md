# Find the Cheater

## Requirements

### Students (agents)

| Members | Methods |
|:-------:|:-------:|
| Moral Value | |
| Friends | |
| Procrastination Likelihood | |

### Professor

| Members | Methods |
|:-------:|:-------:|

-----

### Potential Components

Someone implements the data structure and then the other 2 research 2 of the algorithms and implement one of the 2 algorithms. 

-----

### Code
 
 - Initialize the graph
    - Number of students in the graph
    - Moral code of each student
    - Who is friends with whom
    - Are there other components that students should have?
    - What does the professor know initially?

- What makes an agent cheat?
    - Moral value
    - Peer Pressure - The more people that offer you to cheat the more likely you are to cheat
    - More likely to cheat if the sender has a high grade or does good quality work
    - Add time into the simulation; how much of the project do they have completed when the deadline comes
    - Procrastination is related to how much of the assignment they have finished

- Determining original cheaters
    - Only those with low moral values
    - Pick at random
    - Their friends also have a bad moral value?
    
- Git commands
    - push to a new branch
        - git push remoteName localBranchName:remoteNewBranchName
